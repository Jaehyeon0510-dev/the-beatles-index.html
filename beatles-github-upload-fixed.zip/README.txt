비틀즈 앨범 이미지 GitHub 업로드 파일

업로드 방법:
1. GitHub 저장소의 기존 index.html을 이 압축파일의 index.html로 교체합니다.
2. images 폴더 전체를 저장소 루트에 업로드합니다.
3. 두 항목을 모두 Commit changes 합니다.

저장소 구조는 다음과 같아야 합니다.
/
  index.html
  images/
    abbey-road.png
    a-hard-days-night.png
    beatles-for-sale.png
    help.png
    let-it-be.png
    magical-mystery-tour.png
    please-please-me.png
    revolver.png
    rubber-soul.png
    sgt-peppers-lonely-hearts-club-band.png
    the-beatles-white-album.png
    with-the-beatles.png
    yellow-submarine.png

참고: GitHub에 올린 기본 앨범 이미지는 모든 기기에서 공유됩니다.
브라우저에서 별도로 업로드하는 커스텀 커버는 기존처럼 업로드한 브라우저에만 저장됩니다.
